-- client.lua
print("^2[secretdoor]^0 client loaded")

--[[
Changes in this build:
- "Knock" minigame replaced with Simon-style 4-panel memory game (arrow keys).
- "Candle" minigame shows a rotating needle and a colored target arc around a circle.
- Both draw simple HUD overlays (no NUI) and run in exclusive input mode.
Other features preserved: prompts, job bypass, books/hammer, law reveal/hard-breach,
omit override, legal bomb cues/defuse, rotations, job resolve (statebag→server), debug cmds.
]]

Config = Config or {}
local function C(tbl, key, def) return (tbl and tbl[key] ~= nil) and tbl[key] or def end

-- ===== Debug =====
RegisterCommand("secretdoor_ping", function()
  TriggerEvent('chat:addMessage', { args = { '^2secretdoor', 'client alive' } })
end)

-- ===== Door placements (your doors) =====
local DoorMap = {
  main_door = { pos = vector3(2858.8628, -1194.9165, 47.99144), model = GetHashKey("s_clothingcasedoor01x"), kind="heading", from=94.99994, to=-174.60013 },
  trap_1    = { pos = vector3(1326.0381, -1326.3833, 76.92236),  model = GetHashKey("p_gunsmithtrapdoor01x"), kind="pitch",   from=0.0, to=-89.89913, yaw=165.00002 },
  trap_2    = { pos = vector3(-1790.7443, -390.15039, 159.28944), model = GetHashKey("p_trapdoor01x"),        kind="pitch",   from=0.0, to=-90.0,    yaw=145.08792 },
  trap_3    = { pos = vector3(1259.8738, -406.49283, 96.62240),   model = GetHashKey("p_gunsmithtrapdoor01x"), kind="pitch",   from=0.0, to=-90.0,    yaw=5.0 },
}

-- ===== Controls & helpers =====
local USE_KEY      = 0x760A9C6F -- G
local PROMPT_RANGE = 3.25
local COOLDOWN_MS  = (tonumber(Config.CooldownSeconds or 4) or 4) * 1000
local nextUseAt    = 0

local function coolingDown() return GetGameTimer() < nextUseAt end
local function secsLeft() local d=nextUseAt-GetGameTimer(); return d>0 and math.ceil(d/1000) or 0 end
local function dist(a,b) return Vdist(a.x,a.y,a.z, b.x,b.y,b.z) end
local function getClosestDoorKey(pos, range)
  local bestKey, bestDist
  for k,d in pairs(DoorMap) do
    local dd = dist(pos,d.pos)
    if dd <= (range or PROMPT_RANGE) and (not bestDist or dd<bestDist) then bestKey,bestDist=k,dd end
  end
  return bestKey,bestDist
end
local function findObjAt(coords, modelHash, radius)
  radius=radius or 2.0
  return GetClosestObjectOfType(coords.x,coords.y,coords.z,radius,modelHash,false,false,false)
end

-- ===== Simple HUD drawing (no NUI) =====
local function drawTxtCenter(text, y, a)
  SetTextColor(255,255,255,a or 220)
  SetTextScale(0.45,0.45)
  SetTextCentre(true)
  SetTextFontForCurrentCommand(1)
  DisplayText(CreateVarString(10, "LITERAL_STRING", text), 0.5, y)
end
local function drawRect(x,y,w,h,r,g,b,a) -- 0..1 coords
  DrawRect(x, y, w, h, r, g, b, a)
end
local function deg2rad(d) return d*0.01745329252 end

-- ===== FX helpers (simple) =====
local function PlaySound(name,set) PlaySoundFrontend("FX", name or "NAV_UP", set or "HUD_SHOP_SOUNDSET", true) end

-- ===== Prompts =====
local function makePrompt(keyText, group)
  local p=PromptRegisterBegin()
  PromptSetControlAction(p,USE_KEY)
  PromptSetText(p,CreateVarString(10,"LITERAL_STRING",keyText))
  PromptSetEnabled(p,true); PromptSetVisible(p,true); PromptSetStandardMode(p,true)
  PromptSetGroup(p,group); PromptRegisterEnd(p)
  return p
end
local prompts={}
CreateThread(function()
  local keyText=C(Config.Text,'pressKey',"Press G")
  for k,_ in pairs(DoorMap) do
    local g=GetRandomIntInRange(0,0xffffff)
    prompts[k]={group=g,prompt=makePrompt(keyText,g)}
  end
end)
local function drawGroup(group,text)
  PromptSetActiveGroupThisFrame(group,CreateVarString(10,"LITERAL_STRING",text))
end

-- ===== State =====
local isOpenState={main_door=false,trap_1=false,trap_2=false,trap_3=false}
local OverrideUntilClient={}
local PromptSuspended=false
local MiniInputMode=false

-- expiry cleanup
CreateThread(function()
  while true do
    Wait(1000)
    local t=GetGameTimer()
    for k,e in pairs(OverrideUntilClient) do
      if t>(e or 0) then OverrideUntilClient[k]=nil end
    end
  end
end)

-- ===== Door rotation =====
local function rotHeading(ent,from,to)
  local start,dur=GetGameTimer(),1000
  while GetGameTimer()-start<dur do local t=(GetGameTimer()-start)/dur; SetEntityHeading(ent,from+(to-from)*t); Wait(0) end
  SetEntityHeading(ent,to)
end
local function rotPitch(ent,from,to,yaw)
  local start,dur=GetGameTimer(),1000
  while GetGameTimer()-start<dur do local t=(GetGameTimer()-start)/dur; SetEntityRotation(ent,from+(to-from)*t,0.0,yaw,2,true); Wait(0) end
  SetEntityRotation(ent,to,0.0,yaw,2,true)
end

-- ===== Job lookup (statebag → server fallback; no client vorp exports) =====
local lastJob,lastJobAt=nil,0
local serverJob,serverJobAt=nil,0
local function _requestServerJob() TriggerServerEvent('secretdoor:reqJob') end
RegisterNetEvent('secretdoor:setJob',function(j)
  if type(j)=="table" then serverJob={name=tostring(j.name or ""),grade=tonumber(j.grade or 0) or 0}; serverJobAt=GetGameTimer() end
end)
RegisterNetEvent('secretdoor:pokeJobRefresh',function() _requestServerJob() end)
CreateThread(function() Wait(1000); _requestServerJob() end)
local function getJobFromStatebag()
  local p=Config.JobLock and Config.JobLock.Provider or {}
  local st=LocalPlayer and LocalPlayer.state; if not st then return nil end
  local name=st[p.jobKey or "job"] or st.job or st.jobname or st.jobName or st.Job or st.job_label
  local grade=st[p.gradeKey or "jobGrade"] or st.jobGrade or st.jobgrade or st.rank or st.grade
  if type(name)=="table" then grade=grade or name.grade or name.rank or name.jobGrade; name=name.name or name.job or name.label or name.title end
  if not name then return nil end
  return {name=tostring(name),grade=tonumber(grade or 0) or 0}
end
local function getCurrentJob()
  if lastJob and (GetGameTimer()-lastJobAt)<3000 then return lastJob end
  local job=getJobFromStatebag()
  if not job then
    if not serverJob or (GetGameTimer()-serverJobAt)>15000 then _requestServerJob() end
    job=serverJob
  end
  lastJob,lastJobAt=job,GetGameTimer(); return job
end
RegisterCommand("doorjob",function()
  local j=getCurrentJob()
  if j then TriggerEvent('chat:addMessage',{args={'^2secretdoor',('job=%s grade=%d'):format(j.name, tonumber(j.grade or 0))}}) else TriggerEvent('chat:addMessage',{args={'^1secretdoor','job=nil'}}) end
end)

local function isArray(tbl) if type(tbl)~="table" then return false end for k,_ in pairs(tbl) do if type(k)~="number" then return false end end return next(tbl)~=nil end
local function overrideActiveClient(doorKey) local e=OverrideUntilClient[doorKey]; return e and GetGameTimer()<e end
local function isLawJob() local j=getCurrentJob(); local t=Config.LawInvestigate and Config.LawInvestigate.Jobs or {}; return j and t[string.lower(j.name or "")]==true end

-- ===== Overrides (client mirror) =====
RegisterNetEvent('secretdoor:override:begin', function(doorKey,exp) OverrideUntilClient[doorKey]=exp end)
RegisterNetEvent('secretdoor:law:begin', function(doorKey,exp) OverrideUntilClient[doorKey]=exp end)
RegisterNetEvent('secretdoor:findDoorForOverride', function(range, delayS, windowS)
  local p = GetEntityCoords(PlayerPedId())
  local key = select(1, getClosestDoorKey(p, range))
  TriggerServerEvent('secretdoor:applyDoorOverride', key, delayS, windowS)
end)
RegisterNetEvent('secretdoor:law:findDoor', function(range, delayS, windowS)
  local p = GetEntityCoords(PlayerPedId())
  local key = select(1, getClosestDoorKey(p, range))
  TriggerServerEvent('secretdoor:law:applyDoorReveal', key, delayS, windowS)
end)

-- ===== FX events (bomb/defuse/explosion/rotate) =====
RegisterNetEvent('secretdoor:bomb:plant:fx',function(_) PlaySound("NAV_UP","HUD_SHOP_SOUNDSET") end)
RegisterNetEvent("secretdoor:destroyDoorClient",function(doorKey,blast)
  local d=DoorMap[doorKey]; if not d then return end
  PlaySound("EXPLOSION_MEDIUM","HUD_SHOP_SOUNDSET")
  local ent=findObjAt(d.pos,d.model,2.5); if ent~=0 then SetEntityAsMissionEntity(ent,true,true); DeleteObject(ent) end
  if blast then
    local me=PlayerPedId(); local p=GetEntityCoords(me)
    local radius=tonumber(blast.radius or 7.5) or 7.5
    local maxDmg=tonumber(blast.maxDmg or 100) or 100
    local ragd=tonumber(blast.ragdollS or 5) or 5
    local dd=Vdist(p.x,p.y,p.z, d.pos.x,d.pos.y,d.pos.z)
    if dd<=radius then
      local scale=math.max(0.0,1.0-(dd/radius))
      local dmg=math.floor(maxDmg*scale)
      if dmg>1 then ApplyDamageToPed(me,dmg,false,0,0) end
      if ragd>0 then SetPedToRagdoll(me, ragd*1000, ragd*1000, 0, false,false,false) end
    end
  end
end)
RegisterNetEvent('secretdoor:defuse:start',function(_) PlaySound("NAV_DOWN","HUD_SHOP_SOUNDSET") end)

-- ===== Rotate door =====
RegisterNetEvent("rotateDoorProp",function(doorKey)
  local d=DoorMap[doorKey]; if not d then return end
  local ent=findObjAt(d.pos,d.model,2.5); if ent==0 then return end
  local open=not isOpenState[doorKey]
  if d.kind=="heading" then rotHeading(ent,open and d.from or d.to,open and d.to or d.from) else rotPitch(ent,open and d.from or d.to,open and d.to or d.from,d.yaw or 0.0) end
  isOpenState[doorKey]=open
end)

-- ===== Mini-input mode =====
local function enterMiniInput(allowKeys)
  MiniInputMode = true
  local allow = allowKeys or {}
  CreateThread(function()
    while MiniInputMode do
      DisableAllControlActions(0)
      for _,key in ipairs(allow) do EnableControlAction(0, key, true) end
      Wait(0)
    end
  end)
end
local function leaveMiniInput() MiniInputMode=false end

-- === Simon layout (perfect cross + wood grain tiles) ===
local SIM = { cx = 0.5, cy = 0.58, size = 0.12, gap = 0.018 } -- tweak size/gap if you want
local KEY_UP    = 0x6319DB71
local KEY_DOWN  = 0x05CA7C52
local KEY_LEFT  = 0xA65EBAB4
local KEY_RIGHT = 0xDEB34313

-- utility drawers
local function drawRect(x,y,w,h,r,g,b,a) DrawRect(x,y,w,h,r,g,b,a) end
local function drawTxtCenter(text, x, y, a)
  SetTextColor(0,0,0,a or 230)
  SetTextScale(0.5,0.5)
  SetTextCentre(true)
  SetTextFontForCurrentCommand(1)
  DisplayText(CreateVarString(10,"LITERAL_STRING",text), x, y)
end

-- faux wood grain tile using layered rectangles (no external textures)
local function drawWoodTile(x, y, w, h, active, tint)
  -- base wood color (slightly varied per tile)
  local base = tint or { 156, 115, 72 }
  local r,g,b = base[1], base[2], base[3]
  local alpha = active and 220 or 160
  drawRect(x, y, w, h, r, g, b, alpha)

  -- subtle vignette/border
  drawRect(x, y - h/2 + 0.002, w, 0.004, 0,0,0, 45)
  drawRect(x, y + h/2 - 0.002, w, 0.004, 0,0,0, 45)
  drawRect(x - w/2 + 0.002, y, 0.004, h, 0,0,0, 45)
  drawRect(x + w/2 - 0.002, y, 0.004, h, 0,0,0, 45)

  -- “grain” lines (horizontal darker streaks)
  local lines = 8
  local step  = h / (lines + 1)
  for i=1,lines do
    local yy = y - h/2 + (i * step)
    local a  = active and 55 or 35
    drawRect(x, yy, w * 0.96, 0.003, r-30, g-25, b-20, a)
  end
end

-- arrow glyph on tile
local function drawArrowGlyph(idx, x, y)
  local glyph = ({ "↑", "→", "←", "↓" })[idx]
  drawTxtCenter(glyph, x, y, 235)
end

-- rectangles in a perfect cross (UP, RIGHT, LEFT, DOWN = 1..4)
local function simonRects()
  local cx,cy,s,g = SIM.cx, SIM.cy, SIM.size, SIM.gap
  return {
    {x=cx,      y=cy-(s+g), w=s, h=s}, -- 1 = UP (top)
    {x=cx+(s+g),y=cy,        w=s, h=s}, -- 2 = RIGHT
    {x=cx-(s+g),y=cy,        w=s, h=s}, -- 3 = LEFT
    {x=cx,      y=cy+(s+g),  w=s, h=s}, -- 4 = DOWN (bottom)
  }
end

-- draw all four tiles; highlight one (activeIdx) during playback
local function drawSimonPanels(activeIdx)
  local rects = simonRects()
  local tints = {
    {162,120,78},  -- up
    {170,125,82},  -- right
    {154,112,70},  -- left
    {176,130,86},  -- down
  }
  for i=1,4 do
    drawWoodTile(rects[i].x, rects[i].y, rects[i].w, rects[i].h, i==activeIdx, tints[i])
    drawArrowGlyph(i, rects[i].x, rects[i].y)
  end
  -- header hint
  SetTextColor(255,255,255,235); SetTextScale(0.45,0.45); SetTextCentre(true); SetTextFontForCurrentCommand(1)
  DisplayText(CreateVarString(10,"LITERAL_STRING","REPEAT THE PATTERN WITH ARROW KEYS (or click tiles)"), 0.5, SIM.cy - SIM.size - 0.08)
end

-- input: arrow keys OR left mouse on a tile
local function _cursorToNorm()
  local cx = GetControlNormal(0, 239) -- CURSOR_X
  local cy = GetControlNormal(0, 240) -- CURSOR_Y
  return cx, cy
end
local function _pointInRect(px,py, rect)
  return math.abs(px-rect.x) <= rect.w/2 and math.abs(py-rect.y) <= rect.h/2
end
local function getSimonInput()
  if IsControlJustPressed(0, KEY_UP)    then return 1 end
  if IsControlJustPressed(0, KEY_RIGHT) then return 2 end
  if IsControlJustPressed(0, KEY_LEFT)  then return 3 end
  if IsControlJustPressed(0, KEY_DOWN)  then return 4 end
  if IsControlJustPressed(0, 0x580C4473) then -- MOUSE_BUTTON_LEFT
    local x,y = _cursorToNorm()
    local rects = simonRects()
    for i=1,4 do if _pointInRect(x,y,rects[i]) then return i end end
  end
  return 0
end

-- show sequence with flashes/sound
local function playSimonSequence(seq, beatMs)
  local tNext = GetGameTimer() + 350
  while GetGameTimer() < tNext do Wait(0); drawSimonPanels(0) end
  for i=1,#seq do
    local s = seq[i]
    local start = GetGameTimer()
    while GetGameTimer() - start < beatMs do Wait(0); drawSimonPanels(s) end
    PlaySoundFrontend("FX","NAV_LEFT_RIGHT","HUD_SHOP_SOUNDSET",true)
    local gapStart = GetGameTimer()
    while GetGameTimer() - gapStart < math.floor(beatMs*0.45) do Wait(0); drawSimonPanels(0) end
  end
end

-- main Simon runner (used by knock)
function runSimonMini(rounds, beatMs)
  rounds = rounds or 4
  beatMs = beatMs or 600

  -- exclusive input: arrows + left mouse
  local allow = {KEY_UP,KEY_DOWN,KEY_LEFT,KEY_RIGHT, 0x580C4473}
  MiniInputMode = true
  CreateThread(function() while MiniInputMode do DisableAllControlActions(0) for _,k in ipairs(allow) do EnableControlAction(0,k,true) end Wait(0) end end)

  -- ignore any held G from the door prompt
  while IsControlPressed(0, USE_KEY) do Wait(0) end

  local seq = {}
  math.randomseed(GetGameTimer() + math.random(1000))
  for i=1,rounds do
    seq[i] = math.random(1,4)
    playSimonSequence(seq, beatMs)

    -- collect i inputs
    local idx=1
    while idx<=i do
      Wait(0)
      drawSimonPanels(0)
      local p = getSimonInput()
      if p ~= 0 then
        if p == seq[idx] then
          PlaySoundFrontend("FX","NAV_UP_DOWN","HUD_SHOP_SOUNDSET",true)
          idx = idx + 1
        else
          MiniInputMode=false
          PlaySoundFrontend("FX","ERROR","HUD_SHOP_SOUNDSET",true)
          return false
        end
      end
    end

    -- tiny inter-round pause
    local t=GetGameTimer()+280
    while GetGameTimer()<t do Wait(0); drawSimonPanels(0) end
  end

  MiniInputMode=false
  PlaySoundFrontend("FX","PURCHASE","HUD_SHOP_SOUNDSET",true)
  return true
end


-- ====== Candle (rotating needle & arc) ======
local function drawCircleApprox(cx, cy, rad, thickness, r,g,b,a)
  -- draw ring via small quads
  local segs = 48
  for i=1,segs do
    local ang = (i/segs)*360.0
    local x = cx + math.cos(deg2rad(ang))*rad
    local y = cy + math.sin(deg2rad(ang))*rad
    drawRect(x,y, thickness, thickness, r,g,b,a)
  end
end
local function drawNeedle(cx,cy,rad,ang,r,g,b,a)
  -- simple rectangular needle
  local tipx = cx + math.cos(deg2rad(ang))*rad
  local tipy = cy + math.sin(deg2rad(ang))*rad
  drawRect(tipx, tipy, 0.003, 0.018, r,g,b,a)
end
local function angleInArc(a, startA, endA)
  -- normalize 0..360
  local function norm(x) x = x % 360; if x<0 then x=x+360 end; return x end
  a, startA, endA = norm(a), norm(startA), norm(endA)
  if startA <= endA then
    return a >= startA and a <= endA
  else
    return a >= startA or a <= endA
  end
end

local function runCandleArcMini(speedDegPerSec, arcCenter, arcWidth)
  -- Debounce key and enter exclusive mode
  while IsControlPressed(0, USE_KEY) do Wait(0) end
  enterMiniInput({USE_KEY})

  local cx, cy = 0.5, 0.72
  local rad = 0.09
  local thick = 0.004
  local startA = arcCenter - arcWidth/2
  local endA   = arcCenter + arcWidth/2

  -- wait for initial hold
  while not IsControlJustPressed(0, USE_KEY) do
    Wait(0)
    -- draw ring + arc
    drawCircleApprox(cx,cy,rad,thick,255,255,255,80)
    for a=startA, endA, 6 do
      local x = cx + math.cos(deg2rad(a))*rad
      local y = cy + math.sin(deg2rad(a))*rad
      drawRect(x,y, 0.006, 0.012, 80,220,120, 210)
    end
    drawTxtCenter("Hold G to align the candle to the unlock location", 0.5, 0.46, 230)
  end

  -- rotate while holding
  local ang = 0
  local last=GetGameTimer()
  while IsControlPressed(0, USE_KEY) do
    Wait(0)
    local now=GetGameTimer()
    local dt=(now-last)/1000.0
    last=now
    ang = (ang + speedDegPerSec*dt) % 360

    drawCircleApprox(cx,cy,rad,thick,255,255,255,80)
    for a=startA, endA, 6 do
      local x = cx + math.cos(deg2rad(a))*rad
      local y = cy + math.sin(deg2rad(a))*rad
      drawRect(x,y, 0.006, 0.012, 80,220,120, 210)
    end
    drawNeedle(cx,cy,rad,ang, 240,200,70, 230)
    drawTxtCenter("Hold G to align the candle to the unlock location", 0.5, 0.46, 230)
    drawTxtCenter(("Angle: %03d°   Target: %03d°±%d°"):format(math.floor(ang), math.floor(arcCenter), math.floor(arcWidth/2)), cy-0.15, 230)
  end

  leaveMiniInput()
  local ok = angleInArc(ang, startA, endA)
  PlaySoundFrontend("FX", ok and "PURCHASE_BASKET" or "ERROR", "HUD_SHOP_SOUNDSET")
  return ok
end

-- ===== Books / Hammer (unchanged) =====
local function runBooksMini(opts)
  local ok, res = pcall(function() return exports['tines_minigame']:StartBookshelfTarget(opts) end)
  return ok and (res == true)
end
local function runHammerMini(nails, wood)
  local cfg = { focus = true, cursor = true, nails = nails, type = wood }
  local okInit, mini = pcall(function() return exports['bcc-minigames'].initiate() end)
  if okInit and type(mini)=="table" and mini.Start then
    local done=false; local win=false
    mini.Start('hammertime', cfg, function(result)
      local r=(type(result)=="table") and result.result or result
      win=(r==true); done=true
    end)
    while not done do Wait(0) end
    return win
  else
    local okOld, r = pcall(function() return exports['bcc-minigames']:Start('hammertime', cfg, function(_) end) end)
    return okOld and (r==true or r==nil)
  end
end

-- ===== Minigame router =====
local function runDoorMinigame(doorKey)
  if not Config.MinigamesEnabled then return true end
  local d = Config.Doors and Config.Doors[doorKey]; if not d or not d.useMinigame then return true end
  local mg = d.minigame or { type="none" }
  local t = string.lower(mg.type or "none")
  if t == "none" then
    return true
  elseif t == "knock" then
    -- Simon-style: rounds = patternLen (fallback 4), speed = beatMs
    return runSimonMini(mg.patternLen or 4, mg.beatMs or 600, doorKey)
  elseif t == "candle" then
    -- Rotating needle: speed from holdMs (faster for smaller holdMs), window from windowMs
    local speed = 180 -- deg/sec default
    if tonumber(mg.holdMs) then speed = math.max(60, math.min(360, 120000 / tonumber(mg.holdMs))) end
    local arcWidth = math.max(20, math.min(120, (mg.windowMs or 500)/4))  -- window → arc width
    local arcCenter = 45 + (GetRandomIntInRange(0,6))*45 -- any 45° step for variety
    return runCandleArcMini(speed, arcCenter, arcWidth)
  elseif t == "books" then
    local g = Config.BookshelfGlobal or {}
    return runBooksMini({
      numBooks        = mg.numBooks or g.numBooks or 8,
      timePerRoundSec = mg.timePerRoundSec or g.timePerRoundSec or 5,
      roundsRequired  = mg.roundsRequired or g.roundsRequired or 6,
      correctNeeded   = mg.correctNeeded or g.correctNeeded or 4,
      texts           = g.texts or { targetPrompt = "Click book" }
    })
  elseif t == "hammer" then
    return runHammerMini(mg.nails or 5, mg.wood or "dark-wood")
  end
  return false
end

local function runLawHardBreach()
  local hb = Config.LawInvestigate and Config.LawInvestigate.HardBreach or {}
  if hb.Enabled ~= true then return false end
  local ty = string.lower(hb.type or "knock")
  if     ty == "knock"  then local k=hb.knock  or {}; return runSimonMini(k.patternLen or 5, k.beatMs or 520, nil)
  elseif ty == "candle" then local c=hb.candle or {}; return runCandleArcMini(200, 60, 50)
  elseif ty == "books"  then local b=hb.books  or {}; return runBooksMini({ numBooks=b.numBooks or 10, timePerRoundSec=b.timePerRoundSec or 4, roundsRequired=b.roundsRequired or 7, correctNeeded=b.correctNeeded or 5, texts=(Config.BookshelfGlobal and Config.BookshelfGlobal.texts) or { targetPrompt="Click book" } })
  elseif ty == "hammer" then local h=hb.hammer or {}; return runHammerMini(h.nails or 8, h.wood or "dark-wood")
  end
  return false
end

-- ===== Authorization (client gate; server re-checks) =====
local function isAuthorized(doorKey)
  if Config.JobLock and Config.JobLock.Enabled == false then return true end
  local d = Config.Doors and Config.Doors[doorKey]; if not d then return true end
  local job = getCurrentJob(); if not job or job.name == "" then return false end

  if d.omitJobs and isArray(d.omitJobs) then
    for _,oj in ipairs(d.omitJobs) do
      if tostring(oj):lower() == tostring(job.name):lower() then
        return overrideActiveClient(doorKey)
      end
    end
  end

  local lawSet = Config.LawInvestigate and Config.LawInvestigate.Jobs or {}
  if lawSet[string.lower(job.name or "")] then
    local allow = d.allowedJobs
    local permitted = not allow
    if allow then
      if isArray(allow) then
        for _,name in ipairs(allow) do if tostring(name):lower() == tostring(job.name):lower() then permitted=true break end end
      else
        for name,minGrade in pairs(allow) do
          if tostring(name):lower() == tostring(job.name):lower() then
            permitted = (tonumber(job.grade or 0) or 0) >= (tonumber(minGrade) or 0)
            break
          end
        end
      end
    end
    if not permitted then return overrideActiveClient(doorKey) end
  end

  local allow = d.allowedJobs
  if not allow then return true end
  if isArray(allow) then
    for _,name in ipairs(allow) do if tostring(name):lower() == tostring(job.name):lower() then return true end end
    return false
  else
    for name,minGrade in pairs(allow) do
      if tostring(name):lower() == tostring(job.name):lower() then
        return (tonumber(job.grade or 0) or 0) >= (tonumber(minGrade) or 0)
      end
    end
    return false
  end
end

local function noAccess()
  TriggerEvent('chat:addMessage', { args = { '^1'..(C(Config.JobLock,'NoAccessText',"You don't have access.")) } })
end

-- ===== Try open/close =====
local busy=false
local function setAllPromptsEnabled(on) for _,p in pairs(prompts) do if p and p.prompt then PromptSetEnabled(p.prompt, on) end end end
local function tryOpenClose(doorKey, willOpen, isLawHard)
  if busy then TriggerEvent('chat:addMessage', { args = { '^3'..C(Config.Text,'busy','Busy...') } }); return end
  if not isAuthorized(doorKey) then noAccess(); return end
  local function sendToggle() TriggerServerEvent("secretdoor:toggle", doorKey) end
  if not willOpen then sendToggle(); return end
  if coolingDown() then TriggerEvent('chat:addMessage', { args = { ('^3Please wait %ds...'):format(secsLeft()) } }); return end

  busy = true
  nextUseAt = GetGameTimer() + COOLDOWN_MS

  PromptSuspended = true
  setAllPromptsEnabled(false)

  local ok = (isLawHard and runLawHardBreach()) or runDoorMinigame(doorKey)

  setAllPromptsEnabled(true)
  PromptSuspended = false

  if ok then sendToggle() else TriggerEvent('chat:addMessage', { args = { '^1'..C(Config.Text,'fail','You failed to unlock it.') } }) end
  busy=false
end

-- ===== Prompt loop =====
CreateThread(function()
  while true do
    Wait(0)
    if PromptSuspended then goto continue end
    local p = GetEntityCoords(PlayerPedId())
    for key,meta in pairs(DoorMap) do
      if dist(p, meta.pos) <= PROMPT_RANGE and isAuthorized(key) then
        local law = isLawJob()
        local lawReveal = law and overrideActiveClient(key)
        local text
        if law and not isOpenState[key] and lawReveal then
          text = C(Config.Text,'lawHint',"Press G to attempt breach (hard) or use your legal bomb.")
        else
          local openText = isOpenState[key] and C(Config.Text,'close','Close') or C(Config.Text,'open','Open')
          text = ("%s %s"):format(C(Config.Text,'pressKey','Press G'), openText)
        end
        drawGroup(prompts[key].group, text)
        if PromptHasStandardModeCompleted(prompts[key].prompt) then
          PromptSetEnabled(prompts[key].prompt, false); Wait(120); PromptSetEnabled(prompts[key].prompt, true)
          local useLawHard = law and not isOpenState[key] and lawReveal
          tryOpenClose(key, not isOpenState[key], useLawHard)
        end
      end
    end
    ::continue::
  end
end)

-- ===== Nearest door helper =====
RegisterNetEvent('secretdoor:clientNearestDoor', function(range)
  local p = GetEntityCoords(PlayerPedId())
  local key, d = getClosestDoorKey(p, range or 4.0)
  TriggerServerEvent('secretdoor:clientNearestDoor:resp', key or "", d or -1.0)
end)
