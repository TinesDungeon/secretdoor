fx_version "adamant"
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'
game "rdr3"
lua54 'yes'
author 'Tines' 

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'


dependency 'bcc-minigames'
dependency 'tines_minigame'
dependency 'vorp_core'
dependency 'vorp_inventory'

escrow_ignore {
  'config.lua',
  'client.lua',
  'server.lua',
  'fxmanifest.lua'
}
