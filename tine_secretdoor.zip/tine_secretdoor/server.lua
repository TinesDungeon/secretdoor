-- server.lua
print("^2[secretdoor]^0 server loaded")

local function _norm(s) return s and string.lower(tostring(s)) or nil end

-- =========================
-- Job lookup fallback via VORP Core 3.1
-- =========================
local VorpCore
local function _getCore()
  if VorpCore then return VorpCore end
  local ok, core = pcall(function() return exports.vorp_core:GetCore() end)
  if ok and core then VorpCore = core end
  return VorpCore
end

RegisterNetEvent('secretdoor:reqJob', function()
  local src = source
  local name, grade = "", 0
  local Core = _getCore()
  if Core then
    local user = Core.getUser(src)
    if user and user.getUsedCharacter then
      local char = user.getUsedCharacter
      if char then
        name  = tostring(char.job or char.jobname or char.jobName or char.job_label or ""):lower()
        grade = tonumber(char.jobGrade or char.jobgrade or char.rank or 0) or 0
      end
    end
  end
  TriggerClientEvent('secretdoor:setJob', src, { name = name, grade = grade })
end)

AddEventHandler('playerJoining', function()
  local src = source
  TriggerClientEvent('secretdoor:pokeJobRefresh', src)
end)

-- =========================
-- State
-- =========================
local OverrideUntil = {}  -- [src] = { [doorKey] = expireAtMs }
local DestroyedDoor = {}  -- [doorKey] = true
local ActiveBombs   = {}  -- [doorKey] = { plantedAt=ms, fuseEnd=ms, planter=src }

local function setOverride(src, doorKey, seconds, eventName)
  OverrideUntil[src] = OverrideUntil[src] or {}
  local exp = GetGameTimer() + math.floor((seconds or 60)*1000)
  OverrideUntil[src][doorKey] = exp
  TriggerClientEvent(eventName or 'secretdoor:override:begin', src, doorKey, exp)
end

local function overrideActive(src, doorKey)
  local t = OverrideUntil[src]; if not t then return false end
  local exp = t[doorKey]; if not exp then return false end
  if GetGameTimer() < exp then return true end
  t[doorKey] = nil; if next(t)==nil then OverrideUntil[src] = nil end
  return false
end

-- =========================
-- Omitted override item (VORP Inv 4.2)
-- =========================
CreateThread(function()
  local ov = Config.OmitOverride or {}
  if not ov.enabled then return end
  local item = tostring(ov.item or ""); if item == "" then return end
  local res = "vorp_inventory"
  if not (exports[res] and exports[res].registerUsableItem) then
    print("^3[secretdoor]^0 OmitOverride: missing vorp_inventory.registerUsableItem")
    return
  end
  exports[res]:registerUsableItem(item, function(data)
    local src = data and data.source or source
    if ov.consumeItem == true then pcall(function() exports[res]:subItem(src, item, 1) end) end
    if ov.notify and ov.notify.using then TriggerClientEvent('chat:addMessage', src, { args = { '^3'..ov.notify.using } }) end
    TriggerClientEvent('secretdoor:findDoorForOverride', src, ov.range or 4.0, ov.delaySeconds or 5, ov.windowSeconds or 60)
  end)
  print(("^2[secretdoor]^0 OmitOverride item '%s' registered"):format(item))
end)

RegisterNetEvent('secretdoor:applyDoorOverride', function(doorKey, delaySeconds, windowSeconds)
  local src = source
  if not doorKey or not (Config.Doors and Config.Doors[doorKey]) then return end
  SetTimeout(math.floor((tonumber(delaySeconds) or 5)*1000), function()
    setOverride(src, doorKey, tonumber(windowSeconds) or 60, 'secretdoor:override:begin')
  end)
end)

-- =========================
-- Law Investigate (reveal item)
-- =========================
CreateThread(function()
  local li = Config.LawInvestigate or {}
  if li.Enabled ~= true then return end
  local item = tostring(li.item or ""); if item == "" then return end
  local res = "vorp_inventory"
  if not (exports[res] and exports[res].registerUsableItem) then
    print("^3[secretdoor]^0 LawInvestigate: missing vorp_inventory.registerUsableItem")
    return
  end
  exports[res]:registerUsableItem(item, function(data)
    local src = data and data.source or source
    local job = select(1, (function()
      local Core=_getCore(); if Core then local u=Core.getUser(src); if u and u.getUsedCharacter then local ch=u.getUsedCharacter; if ch then return string.lower(ch.job or ch.jobname or ""), tonumber(ch.jobGrade or 0) or 0 end end end
      return nil,0
    end)())
    if not (job and (Config.LawInvestigate.Jobs or {})[job]) then return end
    if li.consumeItem == true then pcall(function() exports[res]:subItem(src, item, 1) end) end
    if li.notify and li.notify.using then TriggerClientEvent('chat:addMessage', src, { args = { '^3'..li.notify.using } }) end
    TriggerClientEvent('secretdoor:law:findDoor', src, li.range or 6.0, li.delaySeconds or 3, li.windowSeconds or 60)
  end)
  print(("^2[secretdoor]^0 LawInvestigate item '%s' registered"):format(item))
end)

RegisterNetEvent('secretdoor:law:applyDoorReveal', function(doorKey, delaySeconds, windowSeconds)
  local src = source
  if not doorKey or not (Config.Doors and Config.Doors[doorKey]) then return end
  local li = Config.LawInvestigate or {}
  SetTimeout(math.floor((tonumber(delaySeconds) or 3)*1000), function()
    setOverride(src, doorKey, tonumber(windowSeconds) or 60, 'secretdoor:law:begin')
  end)
end)

-- =========================
-- Toggle door (auth + destroyed check)
-- =========================
RegisterNetEvent("secretdoor:toggle")
AddEventHandler("secretdoor:toggle", function(doorKey)
  local src = source
  if DestroyedDoor[doorKey] then
    TriggerClientEvent("chat:addMessage", src, { args = { '^1This door is destroyed.' } })
    return
  end

  -- BYPASS: If job lock is disabled, allow everyone (still respects destroyed state)
  if Config.JobLock and Config.JobLock.Enabled == false then
    TriggerClientEvent("rotateDoorProp", -1, doorKey)
    return
  end

  local doorCfg = Config.Doors and Config.Doors[doorKey]
  if not doorCfg then
    TriggerClientEvent("rotateDoorProp", -1, doorKey)
    return
  end

  -- server-side job check
  local job, grade = (function()
    local Core=_getCore(); if Core then local u=Core.getUser(src); if u and u.getUsedCharacter then local ch=u.getUsedCharacter; if ch then return string.lower(ch.job or ch.jobname or ""), tonumber(ch.jobGrade or 0) or 0 end end end
    return nil,0
  end)()

  if not job then return end

  -- Omitted jobs require active override
  if type(doorCfg.omitJobs)=="table" then
    for _,oj in ipairs(doorCfg.omitJobs) do
      if _norm(oj) == job and not overrideActive(src, doorKey) then
        TriggerClientEvent("chat:addMessage", src, { args = { '^1'..(Config.JobLock and Config.JobLock.NoAccessText or "Denied.") } })
        return
      end
    end
  end

  -- allowedJobs or law reveal requirement
  local allowed = doorCfg.allowedJobs
  if allowed then
    local permitted=false
    local isArr=false; for k,_ in pairs(allowed) do if type(k)=="number" then isArr=true break end end
    if isArr then
      for _,v in ipairs(allowed) do if _norm(v)==job then permitted=true break end end
    else
      local rule=allowed[job]
      if type(rule)=="boolean" then permitted=rule elseif type(rule)=="number" then permitted=(grade>=rule) end
    end
    if not permitted and not ((Config.LawInvestigate and (Config.LawInvestigate.Jobs or {})[job]) and overrideActive(src,doorKey)) then
      TriggerClientEvent("chat:addMessage", src, { args = { '^1'..(Config.JobLock and Config.JobLock.NoAccessText or "Denied.") } })
      return
    end
  else
    -- open to all unless omitted; if law-only reveal desired even without allowedJobs:
    if (Config.LawInvestigate and (Config.LawInvestigate.Jobs or {})[job]) and not overrideActive(src,doorKey) then
      TriggerClientEvent("chat:addMessage", src, { args = { '^1Reveal the door first.' } })
      return
    end
  end

  TriggerClientEvent("rotateDoorProp", -1, doorKey)
end)

-- =========================
-- Legal Bomb: plant (law only)
-- =========================
local LB = Config.LegalBomb or {}

-- Command to plant
if LB.Enabled and LB.Commands and LB.Commands.plant then
  RegisterCommand(LB.Commands.plant, function(source)
    TriggerEvent('secretdoor:legalbomb:request', source, false)
  end, false)
end

-- Usable item to plant
CreateThread(function()
  if not LB.Enabled then return end
  local res = "vorp_inventory"
  if LB.UseItemName and exports[res] and exports[res].registerUsableItem then
    exports[res]:registerUsableItem(LB.UseItemName, function(data)
      local src = data and data.source or source
      TriggerEvent('secretdoor:legalbomb:request', src, true)
    end)
  end
end)

AddEventHandler('secretdoor:legalbomb:request', function(src, viaItem)
  if not LB.Enabled then return end
  local job = (function()
    local Core=_getCore(); if Core then local u=Core.getUser(src); if u and u.getUsedCharacter then local ch=u.getUsedCharacter; if ch then return string.lower(ch.job or ch.jobname or "") end end end
    return nil
  end)()
  if not (job and LB.AllowedJobs and LB.AllowedJobs[job] == true) then
    TriggerClientEvent('chat:addMessage', src, { args = { '^1'..(LB.Notify and LB.Notify.denied or 'Denied.') } })
    return
  end
  if viaItem and LB.RequireItem and LB.UseItemName then
    pcall(function() exports['vorp_inventory']:subItem(src, LB.UseItemName, 1) end)
  end
  TriggerClientEvent('secretdoor:clientNearestDoor', src, LB.RangeToDoor or 4.0)
end)

-- Nearest door response: determine plant vs defuse
RegisterNetEvent('secretdoor:clientNearestDoor:resp')
AddEventHandler('secretdoor:clientNearestDoor:resp', function(doorKey, distVal)
  local src = source
  if not LB.Enabled then return end

  -- DEFUSE ROUTE if a bomb is already active at door
  if doorKey and ActiveBombs[doorKey] then
    TriggerEvent('secretdoor:defuse:proximity', src, doorKey, distVal)
    return
  end

  -- PLANT ROUTE
  if not doorKey or doorKey == "" or DestroyedDoor[doorKey] then
    TriggerClientEvent('chat:addMessage', src, { args = { '^3'..(Config.Text and Config.Text.noDoor or "No door.") } })
    return
  end
  if not (distVal and distVal >= 0 and distVal <= (LB.RangeToDoor or 4.0)) then
    TriggerClientEvent('chat:addMessage', src, { args = { '^3'..(LB.Notify and LB.Notify.cooldown or "Too far.") } })
    return
  end

  -- Plant messages + small FX cue for nearby
  if LB.Notify and LB.Notify.placing then TriggerClientEvent('chat:addMessage', src, { args = { '^3'..LB.Notify.placing } }) end
  TriggerClientEvent('secretdoor:bomb:plant:fx', -1, doorKey)

  SetTimeout(math.floor((LB.PlaceTimeSec or 5) * 1000), function()
    if LB.Notify and LB.Notify.planted then TriggerClientEvent('chat:addMessage', src, { args = { '^2'..LB.Notify.planted } }) end
    local fuseEnd = GetGameTimer() + math.floor((LB.FuseTimeSec or 8) * 1000)
    ActiveBombs[doorKey] = { plantedAt = GetGameTimer(), fuseEnd = fuseEnd, planter = src }

    -- Fuse -> explosion (unless defused)
    SetTimeout(math.floor((LB.FuseTimeSec or 8) * 1000), function()
      if not ActiveBombs[doorKey] then return end -- defused
      ActiveBombs[doorKey] = nil
      DestroyedDoor[doorKey] = true
      TriggerClientEvent('secretdoor:destroyDoorClient', -1, doorKey, {
        radius   = LB.BlastRadius or 7.5,
        maxDmg   = LB.MaxDamage or 100,
        ragdollS = LB.RagdollSeconds or 5
      })
      if LB.Notify and LB.Notify.exploded then
        TriggerClientEvent('chat:addMessage', -1, { args = { '^1'..LB.Notify.exploded } })
      end
    end)
  end)
end)

-- =========================
-- DEFUSE (anyone or restricted; optional item requirement)
-- =========================
-- Command (attempt) — if RequireItem=true, command will inform and stop
if LB.Enabled and LB.Commands and LB.Commands.defuse then
  RegisterCommand(LB.Commands.defuse, function(source)
    local src = source
    local df = LB.Defuse or {}
    if not df.Enabled then return end
    if df.RequireItem then
      TriggerClientEvent('chat:addMessage', src, { args = { '^3'..(df.Text and df.Text.needKit or "You need a defuse kit.") } })
      return
    end
    TriggerClientEvent('secretdoor:clientNearestDoor', src, df.RangeToDoor or 3.0)
  end, false)
end

-- Usable defuse item (starts defuse attempt and optionally consumes)
CreateThread(function()
  local df = LB.Defuse or {}
  if not df.Enabled or not df.ItemName then return end
  local res = "vorp_inventory"
  if exports[res] and exports[res].registerUsableItem then
    exports[res]:registerUsableItem(df.ItemName, function(data)
      local src = data and data.source or source
      if df.RequireItem and df.ConsumeItem then pcall(function() exports[res]:subItem(src, df.ItemName, 1) end) end
      TriggerClientEvent('secretdoor:clientNearestDoor', src, df.RangeToDoor or 3.0)
    end)
  end
end)

-- Proximity check for defuse attempts
AddEventHandler('secretdoor:defuse:proximity', function(src, doorKey, distVal)
  local df = LB.Defuse or {}
  if not df.Enabled then return end
  if not doorKey or doorKey == "" or not ActiveBombs[doorKey] then
    TriggerClientEvent('chat:addMessage', src, { args = { '^3No active charge here.' } })
    return
  end
  if not (distVal and distVal >= 0 and distVal <= (df.RangeToDoor or 3.0)) then
    TriggerClientEvent('chat:addMessage', src, { args = { '^3'..(df.Text and df.Text.tooFar or "Too far.") } })
    return
  end

  -- If AllowAnyone=false, enforce jobs list
  if not df.AllowAnyone then
    local job = (function()
      local Core=_getCore(); if Core then local u=Core.getUser(src); if u and u.getUsedCharacter then local ch=u.getUsedCharacter; if ch then return string.lower(ch.job or ch.jobname or "") end end end
      return nil
    end)()
    if not (job and df.Jobs and df.Jobs[job]) then
      TriggerClientEvent('chat:addMessage', src, { args = { '^1'..(LB.Notify and LB.Notify.denied or 'Denied.') } })
      return
    end
  end

  -- Start defuse minigame on client
  TriggerClientEvent('secretdoor:defuse:start', src, doorKey)
end)

-- Defuse result from client
RegisterNetEvent('secretdoor:defuse:result', function(doorKey, result)
  local src = source
  local df = LB.Defuse or {}
  if not df.Enabled or not doorKey or not ActiveBombs[doorKey] then return end
  local text = df.Text or {}

  if result == true then
    ActiveBombs[doorKey] = nil
    TriggerClientEvent('chat:addMessage', -1, { args = { '^2'..(text.success or "Defused!") } })
  elseif result == "boom" then
    ActiveBombs[doorKey] = nil
    DestroyedDoor[doorKey] = true
    TriggerClientEvent('secretdoor:destroyDoorClient', -1, doorKey, {
      radius   = LB.BlastRadius or 7.5,
      maxDmg   = LB.MaxDamage or 100,
      ragdollS = LB.RagdollSeconds or 5
    })
    TriggerClientEvent('chat:addMessage', -1, { args = { '^1'..(text.fail or "It blew!") } })
  else
    TriggerClientEvent('chat:addMessage', src, { args = { '^3'..(text.fail or "Failed!") } })
  end
end)
