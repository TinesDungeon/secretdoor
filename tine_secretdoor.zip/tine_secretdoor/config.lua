-- config.lua
Config = {}

-- ========== Globals ==========
Config.MinigamesEnabled = true
Config.CooldownSeconds  = 4
Config.DefaultHammer    = { nails = 5, wood = "dark-wood" }

-- UI text
Config.Text = {
  open       = "Open",
  close      = "Close",
  pressKey   = "Press G",
  fail       = "You failed to unlock it.",
  busy       = "This is currently in use.",
  noDoor     = "No nearby door.",
  lawHint    = "Press G to attempt breach (hard) or use your legal bomb.",
  defuseHint = "Press G to start defuse...",
}

-- ========== Bookshelf Target (global) ==========
Config.BookshelfGlobal = {
  Enabled         = true,
  numBooks        = 8,
  timePerRoundSec = 5,
  roundsRequired  = 4,
  correctNeeded   = 3,
  texts = { targetPrompt = "Click book" }
}

-- ========== Job Locking ==========
Config.JobLock = {
  Enabled = false,
  Provider = {
    type       = "export",   -- vorp_core
    resource   = "vorp_core",
    exportName = "GetPlayerJob", -- must return job (or table) compatible with our coalesce
    passSource = true,
  },
  NoAccessText = "You don't have access.",
}

-- ========== Per-door override via usable item (omitted jobs) ==========
Config.OmitOverride = {
  enabled       = true,
  item          = "detectiveverify",
  delaySeconds  = 5,
  windowSeconds = 60,
  range         = 4.0,
  consumeItem   = false,
  notify = {
    using      = "Verification in progress...",
    chooseDoor = "No nearby door detected.",
    granted    = "Access granted for this door.",
    consumed   = "Your verification item was used.",
    expired    = "Your verification access expired.",
  }
}

-- ========== POLICE Investigation Override (law must reveal door first) ==========
-- Law jobs MUST use the same item to reveal/interact with a door for a short window.
Config.LawInvestigate = {
  Enabled = true,
  Jobs    = { sheriff=true, deputy=true, marshal=true, police=true },
  item    = "detectiveverify",  -- reuse same item
  delaySeconds  = 3,            -- small “analysis” delay
  windowSeconds = 60,           -- window of visibility/interaction
  range         = 6.0,
  consumeItem   = false,
  notify = {
    using    = "Analyzing traces...",
    granted  = "Door located. You can attempt a breach or plant a bomb.",
    expired  = "Investigation window expired.",
  },

  -- Harder police breach minigame (no bomb)
  HardBreach = {
    Enabled = true,
    type    = "knock",   -- "knock" | "candle" | "books" | "hammer"
    -- Hard presets for law-only attempt:
    knock   = { patternLen=5, beatMs=520, toleranceMs=120, noiseOnFail=true },
    candle  = { holdMs=2000, windowMs=50, decoys = 5 },
    books   = { numBooks=10, timePerRoundSec=5, roundsRequired=7, correctNeeded=5 },
    hammer  = { nails=12, wood="dark-wood" },
  }
}

-- ========== Legal Bomb (law breach) ==========
Config.LegalBomb = {
  Enabled          = true,
  AllowedJobs      = { sheriff = true, deputy = true, marshal = true, police = true },
  UseItemName      = "legalbomb",   -- optional: item to plant
  RequireItem      = false,         -- if true, consume item on plant
  PlaceTimeSec     = 5,
  FuseTimeSec      = 8,
  BlastRadius      = 7.5,
  MaxDamage        = 100,
  RagdollSeconds   = 5,
  DeleteDoorObject = true,
  RangeToDoor      = 4.0,

  -- ===== DEFUSE SETTINGS (anyone + optional item) =====
  Defuse = {
    Enabled      = true,
    AllowAnyone  = true,            -- when false, only Jobs below may defuse
    Jobs         = { sheriff=true, deputy=true, marshal=true, police=true },

    -- Require a specific item to attempt defuse?
    RequireItem  = false,           -- toggle item requirement
    ItemName     = "defusekit",     -- the item name
    ConsumeItem  = false,           -- consume one on use

    RangeToDoor  = 3.0,
    TimeLimitSec = 10,
    Mini = { taps = 5, beatMs = 500, windowMs = 100, earlyFailDetonate = true },
    Text = {
      start   = "Hold your nerve... defusing!",
      success = "Charge defused!",
      fail    = "You slipped! RUN!",
      tooFar  = "Too far to defuse.",
      needKit = "You need a defuse kit to attempt this.",
    }
  },

  Notify = {
    placing  = "Setting legal charge...",
    planted  = "Charge planted. Stand clear!",
    exploded = "Door breached!",
    denied   = "You are not authorized.",
    cooldown = "Too far from door.",
  },

  Commands = {
    plant  = "legalbomb",   -- /legalbomb to plant (law only)
    defuse = "defusebomb"   -- /defusebomb to attempt a defuse (subject to settings above)
  }
}

-- ========== FX PRESETS (used on client for SFX/VFX) ==========
Config.FX = {
  Explosion = {
    sound    = { mode="fromCoord", name="EXPLOSION_MEDIUM", set="HUD_SHOP_SOUNDSET", volume=1.0 },
    particle = { dict="core", name="ent_amb_explosion", scale=1.35, duration=2500, looped=false },
    camshake = { enabled=true, type="SMALL_EXPLOSION_SHAKE", intensity=0.7, timeMs=1000 }
  },
  BombPlant   = { sound={mode="frontend",name="NAV_UP",set="HUD_SHOP_SOUNDSET",volume=0.7}, particle={dict="core",name="ent_amb_medium_smoke",scale=0.6,duration=800,looped=false} },
  DefuseStart = { sound={mode="frontend",name="NAV_DOWN",set="HUD_SHOP_SOUNDSET",volume=0.7}, particle={dict="core",name="ent_amb_smoke",scale=0.5,duration=800,looped=false} },
  KnockerSuccess = { sound={mode="frontend",name="PURCHASE",set="HUD_SHOP_SOUNDSET",volume=0.6} },
  KnockerFail    = { sound={mode="frontend",name="ERROR",set="HUD_SHOP_SOUNDSET",volume=0.8} },
  CandleSuccess  = { sound={mode="frontend",name="PURCHASE_BASKET",set="HUD_SHOP_SOUNDSET",volume=0.6} },
  CandleFail     = { sound={mode="frontend",name="ERROR",set="HUD_SHOP_SOUNDSET",volume=0.8} },
  DoorOpen       = { sound={mode="frontend",name="CAMP_UPGRADE_TENT",set="HUD_SHOP_SOUNDSET",volume=0.5} },
}

-- ========== Doors ==========
-- Minigame types: "none", "books", "hammer", "knock", "candle"
Config.Doors = {
  main_door = {
    useMinigame  = true,
    minigame     = { type = "books", numBooks = 8, timePerRoundSec = 5, roundsRequired = 4, correctNeeded = 3 },
    omitJobs     = { "sheriff", "deputy","police","bountyhunter" },
  },

  trap_1 = {
    useMinigame  = true,
    minigame     = { type = "candle", holdMs = 1500, windowMs = 100, decoys = 2 },
    omitJobs     = { "sheriff", "deputy","police","bountyhunter"},
  },

  trap_2 = {
    useMinigame  =  true,
    minigame     = { type = "knock", patternLen = 3, beatMs = 600, toleranceMs = 200, noiseOnFail = true },
    omitJobs     = { "sheriff", "deputy","police","bountyhunter" },
  },

  trap_3 = {
    useMinigame  = true,
    minigame     = { type = "hammer", nails = 5, wood = "medium-wood" },
    omitJobs     = {"sheriff", "deputy","police","bountyhunter" },
  },
}
